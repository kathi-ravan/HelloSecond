<?xml version="1.0" encoding="UTF-8" ?>
<!-- 

	Licensed Materials - Property of IBM
	IBM Product Name: 5725I02
	© Copyright IBM Corp. 2005, 2015
	U.S. Government Users Restricted Rights: Use, duplication or disclosure
	restricted by GSA ADP Schedule Contract with IBM Corp.

 -->
<xsl:transform version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
               xmlns:exsl="http://exslt.org/common" extension-element-prefixes="exsl"
               xmlns:v="http://varicent.com/WebReport/RenderXml"
               exclude-result-prefixes="v">
  <xsl:param name="concertMode"/>

  <xsl:template name="replaceLinespace">
    <xsl:param name="string"/>
    <xsl:choose>
      <xsl:when test="string-length($string) = 0">
        <xsl:value-of select="'&#160;'"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$string"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="replaceWhitespace">
    <xsl:param name="string"/>
    <xsl:choose>
      <xsl:when test="string-length($string) = 0">
        <xsl:value-of select="'&#160;'"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:call-template name="replaceNewLine">
          <xsl:with-param name="string" select="$string"/>
        </xsl:call-template>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!--
  All empty cells need to be displayed as a NBSP in order for cells to be properly displayed.
  Text-decorations such as strike-through will however propagate through these "empty" cells (SPM-22769).
  Text-decorations propagate through to the td's and cannot be overridden with text-decoration:none;.
  The only way to stop the decorations from being applied to the td is to wrap the NBSP in another span or div of an inline-block.
  -->
  <xsl:template name="replaceWhitespaceRemoveStyling">
    <xsl:param name="string"/>
    <xsl:choose>
      <xsl:when test="string-length($string) = 0">
        <span style="display:inline-block">
          <xsl:value-of select="'&#160;'"/>
        </span>
      </xsl:when>
      <xsl:otherwise>
        <xsl:call-template name="replaceNewLine">
          <xsl:with-param name="string" select="$string"/>
        </xsl:call-template>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="replaceNewLine">
    <xsl:param name="string"/>
    <xsl:choose>
      <xsl:when test="contains($string,'&#13;&#10;')">
        <xsl:value-of select="substring-before($string,'&#13;&#10;')"/>
        <br/>
        <xsl:call-template name="replaceNewLine">
          <xsl:with-param name="string" select="substring-after($string,'&#13;&#10;')"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="contains($string,'&#10;')">
        <xsl:value-of select="substring-before($string,'&#10;')"/>
        <br/>
        <xsl:call-template name="replaceNewLine">
          <xsl:with-param name="string" select="substring-after($string,'&#10;')"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$string"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template match="v:HtmlSnippet">
    <xsl:value-of select="." disable-output-escaping="yes"/>
  </xsl:template>

  <xsl:template match="v:DropdownCell">
    <select>
      <xsl:attribute name="onchange">
        <xsl:text>cellEndEdit(this)</xsl:text>
      </xsl:attribute>
      <xsl:for-each select="v:Option">
        <xsl:element name="option">
          <xsl:if test="@selected">
            <xsl:attribute name="selected">
              <xsl:text>selected</xsl:text>
            </xsl:attribute>
          </xsl:if>
          <xsl:attribute name="label">
            <xsl:value-of select="v:Name" />
          </xsl:attribute>
          <xsl:value-of select="v:Name" />
        </xsl:element>
      </xsl:for-each>
    </select>
  </xsl:template>

  <!-- Data Grid Display -->
  <xsl:template match="v:DataGridDisplay">
    <div>
      <xsl:attribute name="class">
        <xsl:text>DataGridDiv </xsl:text>
        <xsl:value-of select="v:StyleName" />
        <xsl:choose>
          <xsl:when test="v:FreezeTopRow = 'true'">
            <xsl:text> frozen-area</xsl:text>
          </xsl:when>
        </xsl:choose>
        <xsl:choose>
          <xsl:when test="v:Paginated= 'true'">
            <xsl:text> Paginated</xsl:text>
          </xsl:when>
        </xsl:choose>
      </xsl:attribute>
      <xsl:attribute name="id">
        <xsl:value-of select="v:DataGridDivID" />
      </xsl:attribute>
      <xsl:attribute name="data-gridname">
        <xsl:value-of select="v:Name"/>
      </xsl:attribute>
      <xsl:attribute name="data-reportID">
        <xsl:value-of select="v:ReportID"/>
      </xsl:attribute>
      <xsl:apply-templates select="v:DataGrid" />
    </div>
  </xsl:template>

  <xsl:template match="v:DataGrid">
    <xsl:for-each select="v:HiddenInputRowColumns/v:Column">
      <input type="hidden" name="{v:Name}" value="{v:DefaultValue}" />
    </xsl:for-each>
    <xsl:choose>
      <xsl:when test="v:DataGridInfo/v:IsVertical = 'True'">
        <table>
          <xsl:attribute name="id">
            <xsl:value-of select="v:DataGridID" />
          </xsl:attribute>
          <xsl:for-each select="v:DataGridInfo/v:VerticalInputInfo/v:VerticalTableRow">
            <tr align="left">
              <xsl:attribute name="class">
                <xsl:text>VerticalInputHeader</xsl:text>
              </xsl:attribute>
              <th>
                <xsl:attribute name="class">
                  <xsl:text>DGHeaderVertical</xsl:text>
                </xsl:attribute>
                <div>
                  <xsl:value-of select="v:HeaderCell/v:HeaderValue" />
                </div>
                <div style="display:none;">
                  <span>
                    <xsl:value-of select="v:HeaderCell/v:Type"/>
                  </span>
                  <span>
                    <xsl:value-of select="v:HeaderCell/v:NumericStyle"/>
                  </span>
                  <span>
                    <xsl:value-of select="v:HeaderCell/v:Precision"/>
                  </span>
                </div>
              </th>
              <td align="left">
                <xsl:call-template name="InputRowField" />
              </td>
            </tr>
          </xsl:for-each>
        </table>
      </xsl:when>
      <xsl:otherwise>
        <xsl:if test="count(v:DataRow/v:Row) &gt; 0 or v:EnableShowHideColumns = 'true' or v:EnableExportToExcel = 'true'">
          <xsl:if test="v:EnableShowHideColumns = 'true' or v:EnableExportToExcel = 'true'">
            <div class="showHideContainer">
              <div class="showHideColImgDiv">
                <xsl:attribute name="id">
                  <xsl:value-of select="concat(v:DataGridID, '-dropdown-toggleDiv')" />
                </xsl:attribute>
                <img class="showHideColImg" tag="DataGridOptions" src="../images/triangle_down_blue.png" alt="Data Grid Options">
                  <xsl:attribute name="id">
                    <xsl:value-of select="concat(v:DataGridID, '-dropdown-toggle')" />
                  </xsl:attribute>
                  <xsl:attribute name="name">
                    <xsl:value-of select="v:DataGridName" />
                  </xsl:attribute>
                  <xsl:attribute name="title">
                    <xsl:value-of select="v:DataGridDisplayTooltip" />
                  </xsl:attribute>
                </img>
              </div>
              <!-- this extra div is needed so that we can use absolute positioning for the drop down
                 without pushing other elements down when it appears
  -->

              <div class="showHideColDDRelativePos">
                <div class="showHideColDD">
                  <xsl:attribute name="id">
                    <xsl:value-of select="concat(v:DataGridID, '-dropdown-box')" />
                  </xsl:attribute>
                  <xsl:if test="v:EnableExportToExcel = 'true'">
                    <p tag="ExportToExcelDropdownTitle" > <xsl:value-of select="v:ExportToExcelName" /></p>
                    <div class="exportExcelDDElement">
                      <img class="exportDatagridToXLS exportDataGrid" src="../images/icon_excel2003.png">
                        <xsl:attribute name="name">
                          <xsl:value-of select="v:DataGridName" />
                        </xsl:attribute>
                      </img>
                      <xsl:value-of select="v:ExportToExcelXLS" />
                    </div>
                    <div class="exportExcelDDElement">
                      <img class="exportDatagridToXLSX exportDataGrid" src="../images/icon_excel.png">
                        <xsl:attribute name="name">
                          <xsl:value-of select="v:DataGridName" />
                        </xsl:attribute>
                      </img>
                      <xsl:value-of select="v:ExportToExcelXLSX" />
                    </div>
                    <xsl:if test="v:EnableShowHideColumns = 'true'">
                      <!-- A hack for IE7, other wise just using the <hr/> is okay.
                         The problem is that the hr shows up as a dot, to get around it
                         we wrap it in a div so that the div gets stretched out by the hr
                         (even though the hr itself doesn't stretch...) and then we can
                         put the border on the div instead and hide the hr
  -->
                      <div class="divhr">
                        <hr class="ddseparator" />
                      </div>
                    </xsl:if>
                  </xsl:if>

                  <xsl:if test="v:EnableShowHideColumns = 'true'">
                    <xsl:for-each select="v:DataRow[1]/v:DataGridHeader">
                      <xsl:for-each select="v:HeaderCell">
                        <div class="showHideColDDElement">
                          <input type="hidden">
                            <xsl:attribute name="value">
                              <xsl:value-of select="position() - 1" />
                            </xsl:attribute>
                          </input>
                          <img class="labelCheckImg" src="../images/checkmark.png">
                            <xsl:attribute name="style">
                              <xsl:if test="v:InitiallyShow = 'false'">
                                <xsl:text>visibility:hidden;</xsl:text>
                              </xsl:if>
                            </xsl:attribute>
                          </img>
                          <xsl:value-of select="v:HeaderValue"/>
                        </div>
                      </xsl:for-each>
                    </xsl:for-each>
                  </xsl:if>
                </div>
              </div>
            </div>
          </xsl:if>
        </xsl:if>
        <table>
          <xsl:attribute name="id">
            <xsl:value-of select="v:DataGridID" />
          </xsl:attribute>
          <xsl:attribute name="class">
            <xsl:choose>
              <xsl:when test="v:SuppressPartitionValues = 'true'">
                <xsl:text>SuppressPartitionValues </xsl:text>
                <xsl:value-of select="../v:StyleName" />
                <xsl:text>_Grid</xsl:text>
              </xsl:when>
              <xsl:otherwise>
                <xsl:value-of select="../v:StyleName" />
                <xsl:text>_Grid</xsl:text>
              </xsl:otherwise>
            </xsl:choose>
          </xsl:attribute>

          <xsl:call-template name="ColGroup" />

          <xsl:choose>
            <xsl:when test="count(v:DataRow/v:DataGridHeader) = 1">
              <xsl:apply-templates select="v:DataRow[1]/v:DataGridHeader" />
              <xsl:if test="v:DataGridInfo/v:InputRowAtTop = 'True'">
                <xsl:call-template name="InputRow" />
              </xsl:if>
              <xsl:for-each select="v:DataRow">
                <xsl:apply-templates select="v:Row"/>
                <xsl:apply-templates select="v:Section"/>
              </xsl:for-each>
            </xsl:when>
            <xsl:otherwise>
              <xsl:if test="v:DataGridInfo/v:InputRowAtTop = 'True'">
                <xsl:apply-templates select="v:DataRow[1]/v:DataGridHeader" />
                <xsl:call-template name="InputRow" />
              </xsl:if>
              <xsl:for-each select="v:DataRow">
                <xsl:apply-templates select="v:DataGridHeader"/>
                <xsl:apply-templates select="v:Row"/>
                <xsl:apply-templates select="v:Section"/>
              </xsl:for-each>
            </xsl:otherwise>
          </xsl:choose>

          <xsl:if test="v:DataGridInfo/v:InputRowAtTop = 'False'">
            <xsl:call-template name="InputRow" />
          </xsl:if>

          <xsl:for-each select="v:DataRow">
            <xsl:apply-templates select="v:ComputedRow"/>
          </xsl:for-each>

        </table>
      </xsl:otherwise>
    </xsl:choose>
</xsl:template>

<xsl:template name="ColGroup">
<colgroup>
  <xsl:for-each select="v:DataRow[1]/v:DataGridHeader/v:HeaderCell">
    <col>
      <xsl:attribute name="style">
        <xsl:text>width:</xsl:text>
        <xsl:value-of select="@Width" />
        <xsl:text>%;</xsl:text>
        <xsl:if test="v:InitiallyShow = 'false'">
          <xsl:text>display:none;</xsl:text>
        </xsl:if>
      </xsl:attribute>
    </col>
  </xsl:for-each>
</colgroup>
</xsl:template>

<xsl:template name="InputRowField">
<xsl:choose>
  <xsl:when test="v:InputType = 'Picklist'">
    <span class="spanFilterValues">
      <select class="inputRowSelect" autocomplete="off" name="{v:InputName}">
        <option value=""></option>
        <xsl:for-each select="v:Options/v:Option">
          <xsl:choose>
            <xsl:when test="v:IsDefault = 'true'">
              <option value="{v:Value}" name="{v:Value}" selected="selected"><xsl:value-of select="v:DisplayValue" disable-output-escaping="no" /></option>
            </xsl:when>
            <xsl:otherwise>
              <option value="{v:Value}" name="{v:Value}" ><xsl:value-of select="v:DisplayValue" disable-output-escaping="no" /></option>
            </xsl:otherwise>
          </xsl:choose>
        </xsl:for-each>
      </select>
    </span>
  </xsl:when>
  <xsl:when test="v:InputType = 'Auto-Generate'">
    <input name="{v:InputName}" type="hidden" value="Auto-Generate"></input>
  </xsl:when>
  <xsl:when test="v:InputType = 'TextBox'">
    <div class="outerTextBoxContainer">
      <div class="innerTextBoxContainer">
				<input name="{v:InputName}" value="{v:Value}">
					<xsl:if test="v:InputName/@TextAlignment">
						<xsl:attribute name="style">
		                	<xsl:text>text-align:</xsl:text>
			                <xsl:value-of select="v:InputName/@TextAlignment" />
			                <xsl:text>;</xsl:text>		                
	              		</xsl:attribute>
	              	</xsl:if>
	              	<xsl:if test="@TextAlignment">
						<xsl:attribute name="style">
		                	<xsl:text>text-align:</xsl:text>
			                <xsl:value-of select="@TextAlignment" />
			                <xsl:text>;</xsl:text>		                
	              		</xsl:attribute>
	              	</xsl:if>
				</input>
      </div>
    </div>
  </xsl:when>
  <xsl:when test="v:InputType = 'CommentBox'">
    <div class="outerTextBoxContainer">
      <div class="innerTextBoxContainer">
				<textarea rows="3" name="{v:InputName}">
					<xsl:if test="v:InputName/@TextAlignment">
						<xsl:attribute name="style">
		                	<xsl:text>text-align:</xsl:text>
			                <xsl:value-of select="v:InputName/@TextAlignment" />
			                <xsl:text>;</xsl:text>		                
	              		</xsl:attribute>
	              	</xsl:if>
	              	<xsl:if test="@TextAlignment">
						<xsl:attribute name="style">
		                	<xsl:text>text-align:</xsl:text>
			                <xsl:value-of select="@TextAlignment" />
			                <xsl:text>;</xsl:text>		                
	              		</xsl:attribute>
	              	</xsl:if>
	              	<xsl:value-of select="v:Value" disable-output-escaping="no" />
				</textarea>
      </div>
    </div>
  </xsl:when>
  <xsl:when test="v:InputType = 'DatePicker'">
      <input type="text"  name="{v:InputName}" value="{v:Value}" originalValue="{v:Value}" class="datepickerInput" autocomplete="off">
	      <xsl:if test="v:InputName/@TextAlignment">
			<xsl:attribute name="style">
               	<xsl:text>text-align:</xsl:text>
                <xsl:value-of select="v:InputName/@TextAlignment" />
                <xsl:text>;</xsl:text>		                
            </xsl:attribute>
           </xsl:if>
           <xsl:if test="@TextAlignment">
				<xsl:attribute name="style">
                	<xsl:text>text-align:</xsl:text>
	                <xsl:value-of select="@TextAlignment" />
	                <xsl:text>;</xsl:text>		                
	       		</xsl:attribute>
	       </xsl:if>
      </input>
  </xsl:when>
  <xsl:when test="v:InputType = 'Text'">
    <xsl:attribute name="sortData">
      <xsl:value-of select="v:RawValue"></xsl:value-of>
    </xsl:attribute>
    <xsl:value-of select="v:Value"></xsl:value-of>
  </xsl:when>
  <xsl:otherwise>
  </xsl:otherwise>
</xsl:choose>
</xsl:template>

<xsl:template name="InputRow">
<xsl:if test="v:DataGridInfo/v:DataGridType = 'InputRow'">
  <xsl:choose>
    <xsl:when test="v:DataGridInfo/v:InputRowAtTop = 'True' or count(v:DataRow/v:Row) mod 2">
      <xsl:choose>
        <xsl:when test="../v:StyleName">
          <tr class="{../v:StyleName}_Even InputRow">
            <xsl:for-each select="v:DataGridInfo/v:Columns/v:Column">
              <td>
                <xsl:if test="v:StyleName">
                  <xsl:attribute name="class">
                    <xsl:value-of select="v:StyleName" />
                  </xsl:attribute>
                </xsl:if>
                <xsl:if test="v:InitiallyShow = 'false'">
                  <xsl:attribute name="style"><xsl:text>display:none;</xsl:text></xsl:attribute>
                </xsl:if>
                <xsl:call-template name="InputRowField" />
              </td>
            </xsl:for-each>
            <xsl:apply-templates select="v:DataGridInfo/v:BlankInquiryCopyCell"/>
          </tr>
        </xsl:when>
        <xsl:otherwise>
          <tr class="{../../v:StyleName}_Even InputRow">
            <xsl:for-each select="v:DataGridInfo/v:Columns/v:Column">
              <td>
                <xsl:if test="v:StyleName">
                  <xsl:attribute name="class">
                    <xsl:value-of select="v:StyleName" />
                  </xsl:attribute>
                </xsl:if>
                <xsl:if test="v:InitiallyShow = 'false'">
                  <xsl:attribute name="style"><xsl:text>display:none;</xsl:text></xsl:attribute>
                </xsl:if>
                <xsl:call-template name="InputRowField" />
              </td>
            </xsl:for-each>
            <xsl:apply-templates select="v:DataGridInfo/v:BlankInquiryCopyCell"/>
          </tr>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:when>
    <xsl:otherwise>
      <xsl:choose>
        <xsl:when test="../v:StyleName">
          <tr class="{../v:StyleName}_Odd InputRow">
            <xsl:for-each select="v:DataGridInfo/v:Columns/v:Column">
              <td>
                <xsl:if test="v:StyleName">
                  <xsl:attribute name="class">
                    <xsl:value-of select="v:StyleName" />
                  </xsl:attribute>
                </xsl:if>
                <xsl:if test="v:InitiallyShow = 'false'">
                  <xsl:attribute name="style"><xsl:text>display:none;</xsl:text></xsl:attribute>
                </xsl:if>
                <xsl:call-template name="InputRowField" />
              </td>
            </xsl:for-each>
            <xsl:apply-templates select="v:DataGridInfo/v:BlankInquiryCopyCell"/>
          </tr>
        </xsl:when>
        <xsl:otherwise>
          <tr class="{../../v:StyleName}_Odd InputRow">
            <xsl:for-each select="v:DataGridInfo/v:Columns/v:Column">
              <td>
                <xsl:if test="v:StyleName">
                  <xsl:attribute name="class">
                    <xsl:value-of select="v:StyleName" />
                  </xsl:attribute>
                </xsl:if>
                <xsl:if test="v:InitiallyShow = 'false'">
                  <xsl:attribute name="style"><xsl:text>display:none;</xsl:text></xsl:attribute>
                </xsl:if>
                <xsl:call-template name="InputRowField" />
              </td>
            </xsl:for-each>
            <xsl:apply-templates select="v:DataGridInfo/v:BlankInquiryCopyCell"/>
          </tr>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:otherwise>
  </xsl:choose>
</xsl:if>
</xsl:template>

<xsl:template match="v:Link">
<xsl:param name="value" />
<xsl:variable name="link">
  <xsl:value-of select="@Document" />
  <xsl:choose>
    <xsl:when test="v:Params/v:Param">
      <xsl:text>?</xsl:text>
      <xsl:for-each select="v:Params/v:Param">
        <xsl:value-of select="@Name" />=<xsl:value-of select="."/><xsl:text>&amp;</xsl:text>
      </xsl:for-each>
    </xsl:when>
  </xsl:choose>
	  <xsl:choose>
        <xsl:when test="v:WebTabID">
          <xsl:text>tabId=</xsl:text>
          <xsl:value-of select="v:WebTabID"/>
        </xsl:when>
      </xsl:choose>
</xsl:variable>
<xsl:variable name="tgt">
  <xsl:value-of select="@Target" />
</xsl:variable>
<a href="{$link}" target="{$tgt}">
  <xsl:copy-of select="exsl:node-set($value)"/>
</a>
</xsl:template>

<xsl:template match="v:DataGridHeader">
<tr>
  <xsl:attribute name="class">
    <xsl:text>DGHeaderRow </xsl:text>
    <xsl:value-of select="../../../v:StyleName" />
    <xsl:text>_Header</xsl:text>
    <xsl:choose>
      <xsl:when test="v:FreezeTopRow = 'true'">
        <xsl:text> frozen-header</xsl:text>
      </xsl:when>
    </xsl:choose>
  </xsl:attribute>
  <xsl:if test="@SuppressHeader = 'True'">
    <xsl:attribute name="style">
      <xsl:text>display:none;</xsl:text>
    </xsl:attribute>
  </xsl:if>
  <xsl:for-each select="v:HeaderCell">
    <xsl:choose>
      <xsl:when test="v:CanSort">
        <th>
          <xsl:attribute name="class">
            <xsl:choose>
              <xsl:when test="string-length(@HeaderStyleName)=0" >
                <xsl:value-of select="../../../../v:StyleName" />
                <xsl:text>_Header</xsl:text>
              </xsl:when>
              <xsl:otherwise>
                <xsl:value-of select="@HeaderStyleName" />
              </xsl:otherwise>
            </xsl:choose>
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text> wrapText</xsl:text>
            </xsl:if>
            <xsl:if test="string-length(v:HeaderValue)=0">
              <xsl:text> Empty</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:attribute name="style">
            <xsl:text>width:</xsl:text>
            <xsl:value-of select="@Width" />
            <xsl:text>%;</xsl:text>
            <xsl:if test="v:InitiallyShow = 'false'">
              <xsl:text>display:none;</xsl:text>
            </xsl:if>
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text>max-width:</xsl:text>
              <xsl:value-of select="v:MaxWidth" />
              <xsl:text>px;</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:choose>
            <xsl:when test="string-length(@HeaderStyleName)=0">
              <div>
                <xsl:attribute name="class">
                  <xsl:text>sortingLink reporting_sortingNone </xsl:text>
                  <xsl:value-of select="../../../../v:StyleName" />
                  <xsl:text>_Header</xsl:text>
                </xsl:attribute>
                <xsl:value-of select="v:HeaderValue"/>
              </div>
            </xsl:when>
            <xsl:otherwise>
              <div class="sortingLink reporting_sortingNone {@HeaderStyleName}">
                <xsl:value-of select="v:HeaderValue"/>
              </div>
            </xsl:otherwise>
          </xsl:choose>
          <div style="display:none;">
            <span>
              <xsl:value-of select="v:Type"/>
            </span>
            <span>
              <xsl:value-of select="v:NumericStyle"/>
            </span>
            <span>
              <xsl:value-of select="v:Precision"/>
            </span>
          </div>
        </th>
      </xsl:when>
      <xsl:otherwise>
        <th>
          <xsl:attribute name="class">
            <xsl:text>sorted </xsl:text>
            <xsl:choose>
              <xsl:when test="string-length(@HeaderStyleName)=0" >
                <xsl:value-of select="../../../../v:StyleName" />
                <xsl:text>_Header</xsl:text>
              </xsl:when>
              <xsl:otherwise>
                <xsl:value-of select="@HeaderStyleName" />
              </xsl:otherwise>
            </xsl:choose>
            <xsl:if test="string-length(v:HeaderValue)=0">
              <xsl:text> Empty</xsl:text>
            </xsl:if>
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text> wrapText</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:attribute name="style">
            <xsl:text>width:</xsl:text>
            <xsl:value-of select="@Width" />
            <xsl:text>%;</xsl:text>
            <xsl:if test="v:InitiallyShow = 'false'">
              <xsl:text>display:none;</xsl:text>
            </xsl:if>
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text>max-width:</xsl:text>
              <xsl:value-of select="v:MaxWidth" />
              <xsl:text>px;</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <div><xsl:value-of select="v:HeaderValue"/></div>
          <div style="display:none;">
            <span>
              <xsl:value-of select="v:Type"/>
            </span>
            <span>
              <xsl:value-of select="v:NumericStyle"/>
            </span>
            <span>
              <xsl:value-of select="v:Precision"/>
            </span>
          </div>
        </th>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:for-each>
    <xsl:if test="@EnableInquiryCopy = 'True'">
	  <xsl:call-template name="InquiryCopyHeader">
	      <xsl:with-param name="firstHeaderCell" select="v:HeaderCell[0]"/>
	  </xsl:call-template>
  </xsl:if>
</tr>
</xsl:template>

<xsl:template match="v:Row">
<xsl:choose>
  <xsl:when test="@index = 1">
      <xsl:choose>
        <xsl:when test="v:IsPending = 'true'">
          <tr class="{../../../v:StyleName}_Even pending">
            <xsl:apply-templates select="v:Cell"/>
            <xsl:apply-templates select="v:InquiryCopyCell"/>
          </tr>
        </xsl:when>
        <xsl:otherwise>
    <tr class="{../../../v:StyleName}_Even">
      <xsl:apply-templates select="v:Cell"/>
      <xsl:apply-templates select="v:InquiryCopyCell"/>
    </tr>
        </xsl:otherwise>
      </xsl:choose>
  </xsl:when>
  <xsl:otherwise>
      <xsl:choose>
        <xsl:when test="v:IsPending = 'true'">
          <tr class="{../../../v:StyleName}_Odd pending">
            <xsl:apply-templates select="v:Cell"/>
            <xsl:apply-templates select="v:InquiryCopyCell"/>
          </tr>
        </xsl:when>
        <xsl:otherwise>
    <tr class="{../../../v:StyleName}_Odd">
      <xsl:apply-templates select="v:Cell"/>
      	<xsl:apply-templates select="v:InquiryCopyCell"/>
    </tr>
  </xsl:otherwise>

</xsl:choose>

    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<xsl:template match="v:ComputedRow">
<tr id="{v:ComputedRowID}" class="{../../../v:StyleName}_Computed">
  <xsl:apply-templates select="v:Cell"/>
  <xsl:apply-templates select="v:BlankInquiryCopyCell"/>
</tr>
</xsl:template>

<xsl:template name="InquiryCopyHeader">
 <xsl:param name="firstHeaderCell"/>
 	<th>
       <xsl:attribute name="class">
			<xsl:value-of select="../../../v:StyleName" />
            <xsl:text>_Header</xsl:text>
       </xsl:attribute>
       <xsl:attribute name="style">
			<xsl:text>width:</xsl:text>
            <xsl:value-of select="../v:DataGridHeader/@InquiryCopyColumnWidth" />
            <xsl:text>%;</xsl:text>
       </xsl:attribute>
    </th> 
</xsl:template>

<xsl:template match="v:InquiryCopyCell">
    <xsl:choose>
      <xsl:when test="@Width">
		<td>
		<xsl:attribute name="style">
			<xsl:text>width:</xsl:text>
            <xsl:value-of select="@Width" />
            <xsl:text>%;</xsl:text>
            <xsl:text>white-space:pre-wrap;</xsl:text>
        </xsl:attribute>
        	<img class="{v:ClassName}" src="../images/copy.png" title="{v:Tooltip}" />
   		</td>
      </xsl:when>
      <xsl:otherwise>
        <td>
          <xsl:attribute name="style">
            <xsl:text>white-space:pre-wrap;</xsl:text>
          </xsl:attribute>
          <img class="{v:ClassName}" src="../images/copy.png" title="{v:Tooltip}" />
        </td>
      </xsl:otherwise>
    </xsl:choose>
</xsl:template>

<xsl:template match="v:BlankInquiryCopyCell">
    <xsl:choose>
      <xsl:when test="@Width">
		<td>
		<xsl:attribute name="style">
			<xsl:text>width:</xsl:text>
            <xsl:value-of select="@Width" />
            <xsl:text>%;</xsl:text>
            <xsl:text>white-space:pre-wrap;</xsl:text>
        </xsl:attribute>
   		</td>
      </xsl:when>
      <xsl:otherwise>
        <td>
          <xsl:attribute name="style">
            <xsl:text>white-space:pre-wrap;</xsl:text>
          </xsl:attribute>
        </td>
      </xsl:otherwise>
    </xsl:choose>
</xsl:template>

<xsl:template match="v:Cell">
<xsl:choose>
  <xsl:when test="v:StyleName">
    <xsl:choose>
      <xsl:when test="@Width">
        <td>
          <xsl:attribute name="class">
            <xsl:value-of select="v:StyleName" />
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text> wrapText</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:attribute name="style">
            <xsl:text>width:</xsl:text>
            <xsl:value-of select="@Width" />
            <xsl:text>%;</xsl:text>
            <xsl:text>white-space:pre-wrap;</xsl:text>
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text>max-width:</xsl:text>
              <xsl:value-of select="v:MaxWidth" />
              <xsl:text>px;</xsl:text>
            </xsl:if>
            <xsl:text>vertical-align:</xsl:text>
            <xsl:value-of select="v:VerticalAlignment" />
            <xsl:text>;</xsl:text>
            <xsl:if test="v:InitiallyShow = 'false'">
              <xsl:text>display:none;</xsl:text>
            </xsl:if>
            <xsl:if test="@TextAlignment">
              <xsl:text>text-align:</xsl:text>
              <xsl:value-of select="@TextAlignment" />
              <xsl:text>;</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:attribute name="sortData">
            <xsl:value-of select="v:RawValue"></xsl:value-of>
          </xsl:attribute>
          <xsl:choose>
            <xsl:when test="v:Link">
              <xsl:apply-templates select="v:Link">
                <xsl:with-param name="value">
                  <span>
                    <xsl:value-of select="v:Value"/>
                  </span>
                </xsl:with-param>
              </xsl:apply-templates>
            </xsl:when>
            <xsl:otherwise>
              <xsl:choose>
                <xsl:when test="v:IsEditable = 'false'">
                  <xsl:call-template name="replaceWhitespaceRemoveStyling">
                    <xsl:with-param name="string" select="v:Value"/>
                  </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:call-template name="InputRowField" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:otherwise>
          </xsl:choose>
        </td>
      </xsl:when>
      <xsl:otherwise>
        <td>
          <xsl:attribute name="class">
            <xsl:value-of select="v:StyleName" />
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text> wrapText</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:attribute name="style">
            <xsl:text>white-space:pre-wrap;</xsl:text>
            <xsl:if test="v:InitiallyShow = 'false'">
              <xsl:text>display:none;</xsl:text>
            </xsl:if>
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text>max-width:</xsl:text>
              <xsl:value-of select="v:MaxWidth" />
              <xsl:text>px;</xsl:text>
            </xsl:if>
            <xsl:text>vertical-align:</xsl:text>
            <xsl:value-of select="v:VerticalAlignment" />
            <xsl:text>;</xsl:text>
            <xsl:if test="@TextAlignment">
              <xsl:text>text-align:</xsl:text>
              <xsl:value-of select="@TextAlignment" />
              <xsl:text>;</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:attribute name="sortData">
            <xsl:value-of select="v:RawValue"></xsl:value-of>
          </xsl:attribute>
          <xsl:choose>
            <xsl:when test="v:Link">
              <xsl:apply-templates select="v:Link">
                <xsl:with-param name="value">
                  <span>
                    <xsl:value-of select="v:Value"/>
                  </span>
                </xsl:with-param>
              </xsl:apply-templates>
            </xsl:when>
            <xsl:otherwise>
              <xsl:choose>
                <xsl:when test="v:IsEditable = 'false'">
                  <xsl:call-template name="replaceWhitespaceRemoveStyling">
                    <xsl:with-param name="string" select="v:Value"/>
                  </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:call-template name="InputRowField" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:otherwise>
          </xsl:choose>
        </td>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:when>
  <xsl:otherwise>
    <xsl:choose>
      <xsl:when test="@Width">
        <td>
          <xsl:if test="v:WrapText = 'true'">
            <xsl:attribute name="Class">
              <xsl:text>wrapText</xsl:text>
            </xsl:attribute>
          </xsl:if>
          <xsl:attribute name="style">
            <xsl:text>width:</xsl:text>
            <xsl:value-of select="@Width" />
            <xsl:text>%;</xsl:text>
            <xsl:text>white-space:pre-wrap;</xsl:text>
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text>max-width:</xsl:text>
              <xsl:value-of select="v:MaxWidth" />
              <xsl:text>px;</xsl:text>
            </xsl:if>
            <xsl:text>vertical-align:</xsl:text>
            <xsl:value-of select="v:VerticalAlignment" />
            <xsl:text>;</xsl:text>
            <xsl:if test="v:InitiallyShow = 'false'">
              <xsl:text>display:none;</xsl:text>
            </xsl:if>
            <xsl:if test="@TextAlignment">
              <xsl:text>text-align:</xsl:text>
              <xsl:value-of select="@TextAlignment" />
              <xsl:text>;</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:attribute name="sortData">
            <xsl:value-of select="v:RawValue"></xsl:value-of>
          </xsl:attribute>
          <xsl:choose>
            <xsl:when test="v:Link">
              <xsl:apply-templates select="v:Link">
                <xsl:with-param name="value">
                  <span>
                    <xsl:value-of select="v:Value"/>
                  </span>
                </xsl:with-param>
              </xsl:apply-templates>
            </xsl:when>
            <xsl:otherwise>
              <xsl:choose>
                <xsl:when test="v:IsEditable = 'false'">
                  <xsl:call-template name="replaceWhitespaceRemoveStyling">
                    <xsl:with-param name="string" select="v:Value"/>
                  </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:call-template name="InputRowField" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:otherwise>
          </xsl:choose>
        </td>
      </xsl:when>
      <xsl:otherwise>
        <td>
       	 <xsl:if test="v:WrapText = 'true'">
            <xsl:attribute name="Class">
              <xsl:text>wrapText</xsl:text>
            </xsl:attribute>
          </xsl:if>
          <xsl:attribute name="style">
            <xsl:text>white-space:pre-wrap;</xsl:text>
            <xsl:if test="v:InitiallyShow = 'false'">
              <xsl:text>display:none;</xsl:text>
            </xsl:if>
            <xsl:if test="@TextAlignment">
              <xsl:text>text-align:</xsl:text>
              <xsl:value-of select="@TextAlignment" />
              <xsl:text>;</xsl:text>
            </xsl:if>
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text>max-width:</xsl:text>
              <xsl:value-of select="v:MaxWidth" />
              <xsl:text>px;</xsl:text>
            </xsl:if>
            <xsl:text>vertical-align:</xsl:text>
            <xsl:value-of select="v:VerticalAlignment" />
            <xsl:text>;</xsl:text>
          </xsl:attribute>
          <xsl:attribute name="sortData">
            <xsl:value-of select="v:RawValue"></xsl:value-of>
          </xsl:attribute>
          <xsl:choose>
            <xsl:when test="v:Link">
              <xsl:apply-templates select="v:Link">
                <xsl:with-param name="value">
                  <span>
                    <xsl:value-of select="v:Value"/>
                  </span>
                </xsl:with-param>
              </xsl:apply-templates>
            </xsl:when>
            <xsl:otherwise>
              <xsl:choose>
                <xsl:when test="v:IsEditable = 'false'">
                  <xsl:call-template name="replaceWhitespaceRemoveStyling">
                    <xsl:with-param name="string" select="v:Value"/>
                  </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:call-template name="InputRowField" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:otherwise>
          </xsl:choose>
        </td>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:otherwise>
</xsl:choose>
</xsl:template>

<xsl:template match="v:Section">
<xsl:apply-templates select="v:DataGridHeader"/>
<tr class="_Section">
  <xsl:for-each select="v:SectionCell">
    <xsl:choose>
      <xsl:when test="v:StyleName">
        <td>
          <xsl:attribute name="class">
            <xsl:value-of select="v:StyleName" />
            <xsl:if test="v:WrapText = 'true'">
              <xsl:text> wrapText</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:if test="v:WrapText = 'true'">
            <xsl:text>max-width:</xsl:text>
            <xsl:value-of select="v:MaxWidth" />
            <xsl:text>px;</xsl:text>
          </xsl:if>
          <xsl:if test="v:InitiallyShow = 'false'">
            <xsl:attribute name="style">
              <xsl:text>display:none;</xsl:text>
            </xsl:attribute>
          </xsl:if>
          <xsl:value-of select="v:SectionValue"/>
        </td>
      </xsl:when>
      <xsl:otherwise>
        <td>
          <xsl:if test="v:InitiallyShow = 'false'">
            <xsl:attribute name="style">
              <xsl:text>display:none;</xsl:text>
            </xsl:attribute>
          </xsl:if>
          <xsl:value-of select="v:SectionValue"/>
        </td>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:for-each>
  <xsl:apply-templates select="v:BlankInquiryCopyCell"/>
</tr>
</xsl:template>

        <!--
          The <div> tags are placed around the <xsl:value-of> tags in the xsl.
          The repetition is intended because XSLT with xalan libraries with a version number
          less than 2.7.1 had a problem. Not sure if it was because there were function
          calls between the html tags or if it was something else.
          -->
        <!-- Text Scalar Display -->
<xsl:template match="v:TextScalarDisplay">
<xsl:choose>
  <xsl:when test="v:Link">
    <xsl:apply-templates select="v:Link">
      <xsl:with-param name="value">
        <div>
          <xsl:attribute name="class">
            <xsl:value-of select="v:StyleName" />
          </xsl:attribute>
          <xsl:call-template name="replaceWhitespace">
            <xsl:with-param name="string" select="v:SourceData"/>
          </xsl:call-template>
        </div>
      </xsl:with-param>
    </xsl:apply-templates>
  </xsl:when>
  <xsl:otherwise>
    <div>
      <xsl:attribute name="class">
        <xsl:value-of select="v:StyleName" />
      </xsl:attribute>
      <xsl:call-template name="replaceWhitespace">
        <xsl:with-param name="string" select="v:SourceData"/>
      </xsl:call-template>
    </div>
  </xsl:otherwise>
</xsl:choose>
</xsl:template>

        <!-- Numeric Scalar Display -->
<xsl:template match="v:NumericScalarDisplay">
<xsl:variable name="concertModeNoParam" select="$concertMode and v:IsFromParameter='false'" />
<xsl:choose>
  <xsl:when test="v:Link">
    <xsl:apply-templates select="v:Link">
      <xsl:with-param name="value">
        <div>
          <xsl:attribute name="class">
            <xsl:value-of select="v:StyleName" />
            <xsl:if test="$concertModeNoParam">
              <xsl:text> concertMetric</xsl:text>
            </xsl:if>
          </xsl:attribute>
          <xsl:value-of select="v:SourceData"/>
        </div>
        <xsl:if test="$concertModeNoParam">
          <input type="hidden" name="numericScalarSource">
            <xsl:attribute name="value">
              <xsl:value-of select="v:SourceName"/>
            </xsl:attribute>
          </input>
          <input type="hidden" name="cellType" value="numericScalar" />
          <input type="hidden" name="rawValue">
            <xsl:attribute name="value">
              <xsl:value-of select="v:RawValue" />
            </xsl:attribute>
          </input>
        </xsl:if>
      </xsl:with-param>
    </xsl:apply-templates>
  </xsl:when>
  <xsl:otherwise>
    <div>
      <xsl:attribute name="class">
        <xsl:value-of select="v:StyleName" />
        <xsl:if test="$concertModeNoParam">
          <xsl:text> concertMetric</xsl:text>
        </xsl:if>
      </xsl:attribute>
      <xsl:value-of select="v:SourceData"/>
    </div>
    <xsl:if test="$concertModeNoParam">
      <input type="hidden" name="numericScalarSource">
        <xsl:attribute name="value">
          <xsl:value-of select="v:SourceName"/>
        </xsl:attribute>
      </input>
      <input type="hidden" name="rawValue">
        <xsl:attribute name="value">
          <xsl:value-of select="v:RawValue" />
        </xsl:attribute>
      </input>
      <input type="hidden" name="cellType" value="numericScalar" />
    </xsl:if>
  </xsl:otherwise>
</xsl:choose>
<div style="display:none;">
  <span>
    <xsl:value-of select="v:NumericStyle"/>
  </span>
  <span>
    <xsl:value-of select="v:Precision"/>
  </span>
  <span>
    <xsl:value-of select="v:Original"/>
  </span>
</div>
</xsl:template>

        <!-- Date Scalar Display -->
<xsl:template match="v:DateScalarDisplay">
<xsl:choose>
  <xsl:when test="v:Link">
    <xsl:apply-templates select="v:Link">
      <xsl:with-param name="value">
        <div>
          <xsl:attribute name="class">
            <xsl:value-of select="v:StyleName" />
          </xsl:attribute>
          <xsl:call-template name="replaceLinespace">
            <xsl:with-param name="string" select="v:SourceData"/>
          </xsl:call-template>
        </div>
      </xsl:with-param>
    </xsl:apply-templates>
  </xsl:when>
  <xsl:otherwise>
    <div>
      <xsl:attribute name="class">
        <xsl:value-of select="v:StyleName" />
      </xsl:attribute>
      <xsl:call-template name="replaceLinespace">
        <xsl:with-param name="string" select="v:SourceData"/>
      </xsl:call-template>
    </div>
  </xsl:otherwise>
</xsl:choose>
</xsl:template>

        <!-- Fusion Display -->
<xsl:template match="v:FusionDisplay">
  <xsl:choose>
  <xsl:when test="v:IsD3 = 'true'">
    <div class="{v:StyleName} fusionchart">
      <input type="hidden" class="fusion-chart-name" value="{v:Name}"/>
      <div id = "Fusion_{v:Name}">
        <svg></svg>
      </div>
    </div>

    <script type="text/javascript" >
      try{
      var xml = "<xsl:value-of select="v:Xml" disable-output-escaping="yes"/>";
      var onChartsRendered = function(){numChartsRendered++;};
      var d3Chart = new D3Chart("<xsl:value-of select="v:FilePath" disable-output-escaping="yes"/>", "<xsl:value-of select="v:Name"/>", <xsl:value-of select="v:Width"/>
      , <xsl:value-of select="v:Height"/>, xml, onChartsRendered);

      d3Chart.render("Fusion_" + "<xsl:value-of select="v:Name"/>");
      }catch(ex){
      }
    </script>
  </xsl:when>
  <xsl:otherwise>
    <div class="{v:StyleName} fusionchart">
      <input type="hidden" class="fusion-chart-name" value="{v:Name}"/>
      <div id = "Fusion_{v:Name}">
      </div>
    </div>

    <script type="text/javascript" >

      try{
      var FusionChart = new FusionCharts("<xsl:value-of select="v:FilePath" disable-output-escaping="yes"/>", "<xsl:value-of select="v:Name"/>", <xsl:value-of select="v:Width"/>
      , <xsl:value-of select="v:Height"/>, "0", "1");

      var xml = "<xsl:value-of select="v:Xml" disable-output-escaping="yes"/>";
      xml = xml.replace(/\+/g, "%20");
      FusionChart.setXMLData(decodeURIComponent(xml));

      FusionChart.setTransparent(true);

      if (!!FusionChart._overrideJSChartConfiguration)
      {
      FusionChart._overrideJSChartConfiguration(
      {
      xAxis:
      {
      labels:
      {
      align: "center",
      rotation: 0
      }
      }
      });
      }

      FusionChart.render("Fusion_" + "<xsl:value-of select="v:Name"/>");
      }catch(ex){}
    </script>
  </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<xsl:template match="img">
<img src="{@src}" style="border-style: none"></img>
</xsl:template>

<xsl:template match="div">
<div class="{@class}">
  <xsl:value-of select="."/>
</div>
</xsl:template>

        <!-- Image Scalar Display -->
<xsl:template match="v:ImageDisplay">
<div>
  <xsl:attribute name="class">
    <xsl:value-of select="v:StyleName" />
  </xsl:attribute>
  <xsl:choose>
    <xsl:when test="v:Link">
      <xsl:apply-templates select="v:Link">
        <xsl:with-param name="value">
          <img src = "{v:ImagePath}">
            <xsl:attribute name="title">
              <xsl:value-of select="v:HoverText" />
            </xsl:attribute>
          </img>
        </xsl:with-param>
      </xsl:apply-templates>
    </xsl:when>
    <xsl:otherwise>
      <img src = "{v:ImagePath}">
        <xsl:attribute name="title">
          <xsl:value-of select="v:HoverText" />
        </xsl:attribute>
      </img>
    </xsl:otherwise>
  </xsl:choose>
</div>
</xsl:template>

        <!-- Quick Text Display -->
<xsl:template match="v:QuickTextDisplay">
<pre>
  <xsl:choose>
    <xsl:when test="v:Link">
      <xsl:apply-templates select="v:Link">
        <xsl:with-param name="value">
          <div>
            <xsl:attribute name="class">
              <xsl:value-of select="v:StyleName" />
            </xsl:attribute>
            <xsl:call-template name="replaceLinespace">
              <xsl:with-param name="string" select="v:Text"/>
            </xsl:call-template>
          </div>
        </xsl:with-param>
      </xsl:apply-templates>
    </xsl:when>
    <xsl:otherwise>
      <div>
        <xsl:attribute name="class">
          <xsl:value-of select="v:StyleName" />
        </xsl:attribute>
        <xsl:call-template name="replaceLinespace">
          <xsl:with-param name="string" select="v:Text"/>
        </xsl:call-template>
      </div>
    </xsl:otherwise>
  </xsl:choose>
</pre>
</xsl:template>

        <!-- Document Link Display -->
<xsl:template match="v:DocumentLinkDisplay">
<div class="{v:StyleName}">
  <a href="../documents/download.do?id={v:DocumentID}">
    <xsl:attribute name="style">
      <xsl:text>color:</xsl:text>
      <xsl:text>inherit; </xsl:text>
    </xsl:attribute>
    <xsl:value-of select="v:Text"/>
  </a>
</div>
</xsl:template>

        <!-- Fixed Grid Display -->
<xsl:template match="v:FixedGridDisplay">
<div>
  <xsl:attribute name="class">
    <xsl:text>FixedGridDiv </xsl:text>
    <xsl:value-of select="v:StyleName" />
  </xsl:attribute>
  <xsl:if test="v:EnableExportToExcel = 'true'">
    <div class="showHideContainer">
      <div class="showHideColImgDiv">
        <xsl:attribute name="id">
          <xsl:value-of select="concat(translate(normalize-space(v:FixedGridName), ' ', '-'), '-dropdown-toggleDiv')" />
        </xsl:attribute>
        <img class="showHideColImg" tag="FixedGridOptions" src="../images/triangle_down_blue.png" alt="Fixed Grid Options">
          <xsl:attribute name="id">
            <xsl:value-of select="concat(translate(normalize-space(v:FixedGridName), ' ', '-'), '-dropdown-toggle')" />
          </xsl:attribute>
          <xsl:attribute name="name">
            <xsl:value-of select="v:FixedGridName" />
          </xsl:attribute>
          <xsl:attribute name="title">
            <xsl:value-of select="v:FixedGridDisplayTooltip" />
          </xsl:attribute>
        </img>
      </div>
      <div class="showHideColDDRelativePos">
        <div class="showHideColDD">
          <p tag="ExportToExcelDropdownTitle"><xsl:value-of select="v:ExportToExcelName" /></p>
          <div class="exportExcelDDElement">
            <img class="exportFixedgridToXLS" tag="ExportToExcel2003" src="../images/icon_excel2003.png" alt="Excel">
              <xsl:attribute name="name">
                <xsl:value-of select="v:FixedGridName" />
              </xsl:attribute>
              <xsl:attribute name="title">
                <xsl:value-of select="v:ExcelXlsTooltipTitle" />
              </xsl:attribute>
            </img>
            <xsl:value-of select="v:ExportToExcelXLS" />
          </div>
          <div class="exportExcelDDElement">
            <img class="exportFixedgridToXLSX" tag="ExportToExcel2007" src="../images/icon_excel.png" alt="Excel">
              <xsl:attribute name="name">
                <xsl:value-of select="v:FixedGridName" />
              </xsl:attribute>
              <xsl:attribute name="title">
                <xsl:value-of select="v:ExcelxlsxTooltipTitle" />
              </xsl:attribute>
            </img>
            <xsl:value-of select="v:ExportToExcelXLSX" />
          </div>
        </div>
      </div>
    </div>
  </xsl:if>
  <table class="layoutTable">
    <xsl:for-each select="v:GridRow">
      <tr>
        <xsl:attribute name="class">
          <xsl:value-of select="../v:StyleName" />
          <xsl:text>_Row</xsl:text>
        </xsl:attribute>
        <xsl:for-each select="v:GridCell">
          <td style="width:{@Width}%">
            <xsl:apply-templates select="v:PickListControl"/>
            <xsl:apply-templates select="v:TextControl"/>
            <xsl:apply-templates select="v:SubmitButtonDisplay"/>
            <xsl:apply-templates select="v:QuickTextDisplay"/>
            <xsl:apply-templates select="v:DocumentLinkDisplay"/>
            <xsl:apply-templates select="v:TextScalarDisplay"/>
            <xsl:apply-templates select="v:NumericScalarDisplay"/>
            <xsl:apply-templates select="v:DateScalarDisplay"/>
          </td>
        </xsl:for-each>
      </tr>
    </xsl:for-each>
  </table>
</div>
</xsl:template>

        <!-- Web Specific -->
        <!-- 1. All controls are functional on web -->

        <!-- Text Control -->
<xsl:template match="v:TextControl">
<div class="TextControl">
  <xsl:attribute name="class">
    <xsl:value-of select="v:StyleName" />, TextControl
  </xsl:attribute>
  <input type="text">
    <xsl:attribute name="name">
      <xsl:value-of select="v:Parameter" />
    </xsl:attribute>
    <xsl:attribute name="value">
      <xsl:value-of select="v:ParameterValue" />
    </xsl:attribute>
     <xsl:if test="v:ReadOnly = 1">
     	<xsl:attribute name="readonly"/>
     </xsl:if>
  </input>
  <xsl:if test="v:SourceTable">
    <input type="hidden" class="SourceTable" value="{v:SourceTable}" />
    <input type="hidden" class="SourceNameColumn" value="{v:SourceNameColumn}" />
  </xsl:if>
</div>
</xsl:template>

        <!-- Signature Control -->
<xsl:template match="v:SignatureControl">
<div class="SignatureControl">
  <div>
    <xsl:attribute name="class">
      <xsl:value-of select="v:StyleName" />
    </xsl:attribute>
    <input type="hidden" name="{v:SignatureID}" value="{v:SignatureIDValue}" />
    <textarea>
      <xsl:attribute name="style">
        <xsl:text>resize:</xsl:text>
        <xsl:text>none; </xsl:text>
        <xsl:text>overflow:</xsl:text>
        <xsl:text>auto; </xsl:text>
        <xsl:text>white-space:</xsl:text>
        <xsl:text>pre-wrap; </xsl:text>
        <xsl:text>max-height:</xsl:text>
        <xsl:text>300px; </xsl:text>
        <xsl:text>width:</xsl:text>
        <xsl:text>100%; </xsl:text>
        <xsl:text>font:</xsl:text>
        <xsl:text>inherit; </xsl:text>
        <xsl:text>background-color:</xsl:text>
        <xsl:text>transparent; </xsl:text>
        <xsl:text>border:</xsl:text>
        <xsl:text>none; </xsl:text>
        <xsl:text>text-decoration:</xsl:text>
        <xsl:text>inherit; </xsl:text>
        <xsl:text>color:</xsl:text>
        <xsl:text>inherit; </xsl:text>
        <xsl:text>text-align:</xsl:text>
        <xsl:text>inherit; </xsl:text>
      </xsl:attribute>
      <xsl:attribute name="readonly" />
      <xsl:value-of select="v:AgreementText"/>
    </textarea>
  </div>
  <div>
    <xsl:attribute name="style">
      <xsl:text>margin-top:</xsl:text>
      <xsl:text>2%; </xsl:text>
      <xsl:text>margin-bottom:</xsl:text>
      <xsl:text>3%; </xsl:text>
    </xsl:attribute>
    <label>
      <input type="radio" name="{v:StatusID}" value="0">
        <xsl:attribute name="style">
          <xsl:text>margin-right:</xsl:text>
          <xsl:value-of select="0.5" />
          <xsl:text>%;</xsl:text>
          <xsl:text>margin-bottom:</xsl:text>
          <xsl:value-of select="1" />
          <xsl:text>%;</xsl:text>
        </xsl:attribute>
        <xsl:choose>
          <xsl:when test="v:RejectedStatus = 'true'">
            <xsl:attribute name="checked">
              <xsl:text>checked</xsl:text>
            </xsl:attribute>
          </xsl:when>
        </xsl:choose>
      </input>
      <xsl:value-of select="v:RejectText"/>
    </label>
    <label>
      <input type="radio" name="{v:StatusID}" value="1">
        <xsl:attribute name="style">
          <xsl:text>margin-left:</xsl:text>
          <xsl:value-of select="2" />
          <xsl:text>%;</xsl:text>
          <xsl:text>margin-right:</xsl:text>
          <xsl:value-of select="0.5" />
          <xsl:text>%;</xsl:text>
          <xsl:text>margin-bottom:</xsl:text>
          <xsl:value-of select="1" />
          <xsl:text>%;</xsl:text>
        </xsl:attribute>
        <xsl:choose>
          <xsl:when test="v:RejectedStatus = 'false'">
            <xsl:attribute name="checked">
              <xsl:text>checked</xsl:text>
            </xsl:attribute>
          </xsl:when>
        </xsl:choose>
      </input>
      <xsl:value-of select="v:AcceptText"/>
    </label>
  </div>
</div>
</xsl:template>

        <!-- Workflow Link Control -->
<xsl:template match="v:WorkflowLinkControl">
<div>
  <xsl:attribute name="class">
    <xsl:value-of select="v:StyleName" />
  </xsl:attribute>
  <table>
    <xsl:attribute name="class">
      <xsl:value-of select="v:StyleName" />
    </xsl:attribute>
    <thead class="{v:StyleName}_Header">
      <tr>
        <xsl:for-each select="v:ColumnHeaders/v:Column">
          <th> <xsl:value-of select="self::node()"/> </th>
        </xsl:for-each>
      </tr>
    </thead>
    <xsl:for-each select="v:WorkflowLink">
      <xsl:choose>
        <xsl:when test="(position()) mod 2 = 1">
          <tr class="{../v:StyleName}_Primary">
            <xsl:for-each select="v:Cell">
              <td>
                <a>
                  <xsl:attribute name="href">
                    <xsl:value-of select="v:URL" />
                  </xsl:attribute>
                  <xsl:value-of select="v:Value" />
                </a>
              </td>
            </xsl:for-each>
          </tr>
        </xsl:when>
        <xsl:otherwise>
          <tr class="{../v:StyleName}_Secondary">
            <xsl:for-each select="v:Cell">
              <td>
                <a>
                  <xsl:attribute name="href">
                    <xsl:value-of select="v:URL" />
                  </xsl:attribute>
                  <xsl:value-of select="v:Value" />
                </a>
              </td>
            </xsl:for-each>
          </tr>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:for-each>
  </table>
</div>
</xsl:template>


        <!-- Pick List Control -->
<xsl:template match="v:PickListControl">
<div>
  <xsl:attribute name="class">
    <xsl:value-of select="v:StyleName" />
    <xsl:value-of select="v:Name" />
  </xsl:attribute>
  <input type="hidden" class="NamePL" value="{v:PLName}"/>
  <input type="hidden" class="SourceTable" value="{v:SourceTable}"/>
  <input type="hidden" class="SourceIDColumn" value="{v:SourceIDColumn}"/>
  <input type="hidden" class="SourceNameColumn" value="{v:SourceNameColumn}"/>
  <input type="hidden" class="FillsParameter" value="{v:Parameter}"/>
  <input type="hidden" class="SortCol" value="{v:SortCol}"/>
  <input type="hidden" class="SortDescending" value="{v:SortDescending}"/>
  <input type="hidden" class="HideId" value="{v:HideId}"/>
  <xsl:if test="v:ReadOnly = 1">
  	<input type="hidden" name="{v:Parameter}" value="{v:ParameterValue}" />
  </xsl:if>
  
  <xsl:for-each select="v:SourceParam">
    <input type="hidden">
      <xsl:attribute name="class">SourceParam</xsl:attribute>
      <xsl:attribute name="id">
        <xsl:value-of select="." />
      </xsl:attribute>
      <xsl:attribute name="value" >
        <xsl:value-of select="@DefaultValue" />
      </xsl:attribute>
    </input>
  </xsl:for-each>
  <img name="spinner" class="picklist-img" src="../images/spinner.gif" alt="Loading" title="Loading" />
  <img name="info" class="picklist-img" src="../images/inquiry.png" alt="Loading" title="Loading" />
  <span class="spanFilterValues">
    <select class="{v:StyleName}_Control">
      <xsl:if test="v:ReadOnly = 1">
     	<xsl:attribute name="disabled"/>
      </xsl:if>
      <xsl:attribute name="name">
        <xsl:value-of select="v:Parameter" />
      </xsl:attribute>
      <xsl:attribute name="style">
        <xsl:text>min-width:120px;</xsl:text>
      </xsl:attribute>
      <xsl:choose>
        <xsl:when test="v:ParameterValue != ''">
          <option class="{v:StyleName}_Control"></option>
        </xsl:when>
        <xsl:otherwise>
          <option selected="true" class="{v:StyleName}_Control"></option>
        </xsl:otherwise>
      </xsl:choose>
      <xsl:choose>
        <xsl:when test="@HideID">
          <xsl:for-each select="v:SourceData/v:ID">
            <xsl:choose>
              <xsl:when test="v:Value = ../../v:ParameterValue">
                <option selected="true" class="{v:StyleName}_Control">
                  <xsl:attribute name="value">
                    <xsl:value-of select="v:Value" disable-output-escaping="yes"/>
                  </xsl:attribute>
                  <xsl:value-of select="v:Name" disable-output-escaping="yes"/>
                </option>
              </xsl:when>
              <xsl:otherwise>
                <option class="{v:StyleName}_Control">
                  <xsl:attribute name="value">
                    <xsl:value-of select="v:Value" disable-output-escaping="yes"/>
                  </xsl:attribute>
                  <xsl:value-of select="v:Name" disable-output-escaping="yes"/>
                </option>
              </xsl:otherwise>
            </xsl:choose>
          </xsl:for-each>
        </xsl:when>
        <xsl:otherwise>
          <xsl:for-each select="v:SourceData/v:ID">
            <xsl:choose>
              <xsl:when test="v:Value = ../../v:ParameterValue">
                <option selected="true" class="{v:StyleName}_Control">
                  <xsl:attribute name="value">
                    <xsl:value-of select="v:Value" disable-output-escaping="yes"/>
                  </xsl:attribute>
                  (<xsl:value-of select="v:Value" disable-output-escaping="yes"/>) <xsl:value-of select="v:Name" disable-output-escaping="yes"/>
                </option>
              </xsl:when>
              <xsl:otherwise>
                <option class="{v:StyleName}_Control">
                  <xsl:attribute name="value">
                    <xsl:value-of select="v:Value" disable-output-escaping="yes"/>
                  </xsl:attribute>
                  (<xsl:value-of select="v:Value" disable-output-escaping="yes"/>) <xsl:value-of select="v:Name" disable-output-escaping="yes"/>
                </option>
              </xsl:otherwise>
            </xsl:choose>
          </xsl:for-each>
        </xsl:otherwise>
      </xsl:choose>
    </select>
  </span>
</div>
</xsl:template>

        <!-- Submit Button -->
<xsl:template match="v:SubmitButtonDisplay">
<button type="submit">
  <xsl:attribute name="name">
    <xsl:value-of select="v:Name" />
  </xsl:attribute>
  <xsl:attribute name="class">
    <xsl:value-of select="v:StyleName" />
  </xsl:attribute>
  <xsl:value-of select="v:ButtonText"/>
</button>
</xsl:template>

        </xsl:transform>